import { ParsedAnswerKeyData, QuestionData } from '../../types';
import { calculateRawScore } from '../scoring';
import { EXAM_SHIFTS } from '../../data/shifts';

/**
 * Bulletproof Quoted-Printable Decoder for MHTML
 * Handles soft line breaks (=\r?\n), ASCII escapes (=3D, =20),
 * and multi-byte UTF-8 hex sequences (=E0=A4=B0...) without breaking Unicode.
 */
export function decodeQuotedPrintable(input: string): string {
  // 1. Remove soft line breaks: equal sign followed by newline
  const clean = input.replace(/=\r?\n/g, '');

  let result = '';
  const byteBuffer: number[] = [];

  const flush = () => {
    if (byteBuffer.length > 0) {
      try {
        result += new TextDecoder('utf-8', { fatal: false }).decode(new Uint8Array(byteBuffer));
      } catch {
        result += byteBuffer.map((b) => String.fromCharCode(b)).join('');
      }
      byteBuffer.length = 0;
    }
  };

  for (let i = 0; i < clean.length; i++) {
    if (
      clean[i] === '=' &&
      i + 2 < clean.length &&
      /^[0-9A-Fa-f]{2}$/.test(clean.substring(i + 1, i + 3))
    ) {
      byteBuffer.push(parseInt(clean.substring(i + 1, i + 3), 16));
      i += 2;
    } else {
      flush();
      result += clean[i];
    }
  }
  flush();
  return result;
}

/**
 * Unpacks MHTML archives to extract pristine HTML, or returns raw content if already HTML.
 */
export function unpackMHTML(rawContent: string): string {
  if (!rawContent) return '';

  const isMhtml =
    rawContent.includes('MIME-Version:') ||
    rawContent.includes('multipart/related') ||
    rawContent.includes('Content-Type:') ||
    rawContent.includes('From: <Saved by Blink>');

  if (!isMhtml) {
    // If not MHTML header, check if it's quoted-printable encoded HTML
    if (rawContent.includes('=3D') || /=\r?\n/.test(rawContent)) {
      return decodeQuotedPrintable(rawContent);
    }
    return rawContent;
  }

  // 1. Extract boundary
  const boundaryMatch = rawContent.match(/boundary="?([^"\r\n;]+)"?/i);
  let htmlChunk = '';

  if (boundaryMatch) {
    const boundary = boundaryMatch[1];
    const parts = rawContent.split('--' + boundary);
    for (const part of parts) {
      if (
        /Content-Type:\s*text\/html/i.test(part) ||
        /=3Chtml/i.test(part) ||
        /<html/i.test(part) ||
        /class=["']?question/i.test(part) ||
        /class=3D["']?menu-tbl/i.test(part)
      ) {
        htmlChunk = part;
        break;
      }
    }
  }

  // Fallback: search for text/html or <html if boundary split didn't find it
  if (!htmlChunk) {
    const htmlTypeIndex = rawContent.search(/Content-Type:\s*text\/html/i);
    if (htmlTypeIndex !== -1) {
      htmlChunk = rawContent.slice(htmlTypeIndex);
    } else {
      const htmlTagIndex = rawContent.search(/<html|=3Chtml/i);
      if (htmlTagIndex !== -1) {
        htmlChunk = rawContent.slice(htmlTagIndex);
      } else {
        htmlChunk = rawContent;
      }
    }
  }

  // Separate MIME headers from the body in this part
  const headerSplit = htmlChunk.search(/\r?\n\r?\n/);
  let headers = '';
  let body = htmlChunk;
  if (headerSplit !== -1) {
    headers = htmlChunk.slice(0, headerSplit);
    body = htmlChunk.slice(headerSplit).replace(/^\r?\n\r?\n/, '');
  }

  // Check encoding
  const isQP =
    /Content-Transfer-Encoding:\s*quoted-printable/i.test(headers) ||
    body.includes('=3D') ||
    /=\r?\n/.test(body);

  if (isQP) {
    return decodeQuotedPrintable(body);
  }

  if (/Content-Transfer-Encoding:\s*base64/i.test(headers)) {
    try {
      const clean = body.replace(/[^A-Za-z0-9+/=]/g, '');
      const binary = atob(clean);
      const bArray = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bArray[i] = binary.charCodeAt(i);
      }
      return new TextDecoder('utf-8', { fatal: false }).decode(bArray);
    } catch {
      return body;
    }
  }

  return body;
}

/**
 * Determine Shift Number (1..22) based on date string and time/shift label
 */
export function determineShiftNumber(dateStr: string, timeStr: string, examNameStr: string = ''): number {
  const combined = `${timeStr} ${examNameStr} ${dateStr}`.toLowerCase();

  // 1. Direct shift match if explicit "Shift 1" .. "Shift 22" or "S1" .. "S22"
  const directShiftMatch = combined.match(/(?:shift|पारी|session)\s*[:#-]?\s*(\d{1,2})\b/i);
  if (directShiftMatch) {
    const sNum = parseInt(directShiftMatch[1], 10);
    if (sNum >= 1 && sNum <= 22) return sNum;
  }

  // 2. Date match
  const dayMatch = dateStr.match(/(\d{1,2})[-\/.](\d{1,2})/);
  let targetDay = dayMatch ? parseInt(dayMatch[1], 10) : 23;
  let targetMonth = dayMatch ? parseInt(dayMatch[2], 10) : 9;

  // Check for month names like "sep", "sept", "oct"
  if (/oct|अक्टूबर/i.test(dateStr)) targetMonth = 10;
  if (/sep|सितम्बर/i.test(dateStr)) targetMonth = 9;

  // Check for morning vs afternoon
  const isMorning = /09:00|9:00|am|प्रातः|morning|s1|sh1|शिफ्ट\s*1/i.test(combined);
  const isAfternoon = /14:30|02:30|2:30|pm|दोपहर|afternoon|s2|sh2|शिफ्ट\s*2/i.test(combined);

  for (const shift of EXAM_SHIFTS) {
    const sDate = new Date(shift.date);
    if (sDate.getDate() === targetDay && sDate.getMonth() + 1 === targetMonth) {
      if (isMorning && shift.shiftTime === 'Morning') return shift.shiftNumber;
      if (isAfternoon && shift.shiftTime === 'Afternoon') return shift.shiftNumber;
    }
  }

  // Fallback to day matching alone
  for (const shift of EXAM_SHIFTS) {
    const sDate = new Date(shift.date);
    if (sDate.getDate() === targetDay) {
      if (isAfternoon && shift.shiftTime === 'Afternoon') return shift.shiftNumber;
      return shift.shiftNumber;
    }
  }

  return 1;
}

/**
 * Universal MPESB / TCS / Vyapam CBT Exam Answer Key Parser
 */
export class AnswerKeyParser {
  public parse(rawContent: string, fileName: string = ''): ParsedAnswerKeyData {
    if (!rawContent || rawContent.trim().length === 0) {
      throw new Error('अपलोड की गई फ़ाइल या सामग्री खाली है। कृपया वैध HTML या MHTML फ़ाइल चुनें या कोड पेस्ट करें।');
    }

    // Step 1: Unpack MHTML if needed
    const html = unpackMHTML(rawContent);

    // Step 2: Parse DOM
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    let candidateName = '';
    let rollNumber = '';
    let examDate = '';
    let testTime = '';
    let examinationName = '';

    // Strategy 1: Iterate all table rows (Handles MPESB cbtexam.in & TCS iON tables)
    const rows = doc.querySelectorAll('tr');
    rows.forEach((row) => {
      const cells = row.querySelectorAll('td, th');
      if (cells.length >= 2) {
        for (let i = 0; i < cells.length - 1; i++) {
          const label = cells[i].textContent?.trim().toLowerCase().replace(/\s+/g, ' ') || '';
          const val = cells[i + 1].textContent?.trim() || '';

          // Roll Number (Digits)
          if (
            !rollNumber &&
            (label.includes('roll number') ||
              label.includes('roll no') ||
              label.includes('अनुक्रमांक') ||
              label.includes('participant id') ||
              label.includes('application no') ||
              label.includes('पंजीयन'))
          ) {
            const digitMatch = val.match(/(\d{6,20})/);
            if (digitMatch) {
              rollNumber = digitMatch[1];
            }
          }

          // Candidate Name
          if (
            !candidateName &&
            !label.includes('examination') &&
            !label.includes('exam') &&
            !label.includes('center') &&
            (label.includes('name of the candidate') ||
              label.includes('candidate name') ||
              label.includes('participant name') ||
              label.includes('परीक्षार्थी का नाम') ||
              label.includes('अभ्यर्थी का नाम') ||
              label === 'name' ||
              label === 'नाम')
          ) {
            const cleanVal = val.replace(/^[:\s-]+/, '').trim();
            if (cleanVal.length >= 2 && !/^(roll|exam|date|shift|test)/i.test(cleanVal)) {
              candidateName = cleanVal;
            }
          }

          // Examination Name
          if (
            !examinationName &&
            (label.includes('examination name') ||
              label.includes('exam name') ||
              label.includes('subject') ||
              label.includes('विषय'))
          ) {
            examinationName = val;
          }

          // Exam Date & Time
          if (
            !examDate &&
            (label.includes('exam date') ||
              label.includes('test date') ||
              label.includes('परीक्षा दिनांक') ||
              label.includes('दिनांक'))
          ) {
            const dMatch = val.match(/(\d{1,2}[-\/.]\d{1,2}[-\/.]\d{2,4})/);
            if (dMatch) examDate = dMatch[1];

            const tMatch = val.match(/(\d{1,2}:\d{2}(?:\s*[AaPp][Mm])?)/);
            if (tMatch) testTime = tMatch[1];
          }

          // Test Time explicitly
          if (
            !testTime &&
            (label.includes('test time') ||
              label.includes('exam time') ||
              label.includes('समय') ||
              label.includes('shift'))
          ) {
            testTime = val;
          }
        }
      }
    });

    // Strategy 2: Text & Regex scanning fallback if DOM table structures varied
    const allText = doc.body ? doc.body.textContent || '' : html;

    if (!rollNumber) {
      const rollMatch =
        html.match(/<td[^>]*>\s*Roll\s*(?:Number|No\.?)[\s\S]*?<\/td>\s*<td[^>]*>[\s\S]*?(\d{6,20})/i) ||
        allText.match(/(?:Roll\s*(?:Number|No\.?)|Participant\s*ID|अनुक्रमांक|Application\s*No\.?)[^\d]{1,50}(\d{6,20})/i) ||
        allText.match(/\b(2\d{7,11})\b/) ||
        allText.match(/\b(3\d{9,13})\b/);
      if (rollMatch) rollNumber = rollMatch[1].trim();
    }

    if (!candidateName) {
      const nameMatch =
        html.match(/<td[^>]*>\s*Name\s*(?:of\s*the\s*Candidate)?\s*<\/td>\s*<td[^>]*>\s*([^<]+)\s*<\/td>/i) ||
        allText.match(/(?:Name\s*of\s*the\s*Candidate|Candidate\s*Name|परीक्षार्थी\s*का\s*नाम|अभ्यर्थी\s*का\s*नाम)[:\s.-]*([A-Za-z\u0900-\u097F][A-Za-z\s.'\u0900-\u097F]{2,35}?)(?=\s*(?:Roll|Father|Exam|Date|Test|Shift|Subject|\n|\r|$))/i);
      if (nameMatch) {
        const clean = nameMatch[1].trim();
        if (clean.length >= 2 && !/^(roll|exam|date|test)/i.test(clean)) {
          candidateName = clean;
        }
      }
    }

    if (!examDate) {
      const dateMatch = allText.match(/(?:Exam\s*Date|Test\s*Date|परीक्षा\s*दिनांक|दिनांक)[^\d]{1,50}(\d{1,2}[-\/.]\d{1,2}[-\/.]\d{2,4})/i);
      if (dateMatch) examDate = dateMatch[1].trim();
    }

    if (!testTime) {
      const timeMatch = allText.match(/(\d{1,2}:\d{2}\s*(?:AM|PM|am|pm)?)/);
      if (timeMatch) testTime = timeMatch[1].trim();
    }

    if (!examinationName) {
      const exMatch = allText.match(/(?:Examination\s*Name|Exam\s*Name|परीक्षा\s*का\s*नाम)[:\s.-]*([^\r\n<]+)/i);
      if (exMatch) examinationName = exMatch[1].trim();
    }

    // Determine Shift Number (1..22)
    const finalDate = examDate || '23/09/2026';
    const shiftNumber = determineShiftNumber(finalDate, testTime, examinationName);

    // Step 3: Extract Questions
    const questions: QuestionData[] = [];

    // =========================================================================
    // Parser Engine 1: MPESB cbtexam.in Format
    // Pattern: "Answer Given by Candidate:- ..., Option ID : -XXXXX"
    //          "Correct Answer :- ... Option ID :- XXXXX"
    // =========================================================================
    const mpesbBlockRegex = /(?:Answer\s*Given\s*by\s*Candidate|दिया\s*गया\s*उत्तर)[\s:-]*([\s\S]*?)(?:Correct\s*Answer|सही\s*उत्तर)[\s:-]*([\s\S]*?)(?=(?:Answer\s*Given|दिया\s*गया\s*उत्तर|Question|प्रश्न|$))/gi;
    let mpesbMatch;
    let qIndex = 1;

    while ((mpesbMatch = mpesbBlockRegex.exec(html)) !== null) {
      const givenBlock = mpesbMatch[1];
      const correctBlock = mpesbMatch[2];

      const isNotAttempted = /Not\s*Attempted|नहीं\s*दिया/i.test(givenBlock);
      const givenOptMatch = givenBlock.match(/(?:Option\s*ID|विकल्प\s*आईडी|Option)\s*[:\s-]+(\d+)/i) || givenBlock.match(/Option\s*([1-4])/i);
      const correctOptMatch = correctBlock.match(/(?:Option\s*ID|विकल्प\s*आईडी|Option)\s*[:\s-]+(\d+)/i) || correctBlock.match(/Option\s*([1-4])/i);

      const givenId = givenOptMatch ? givenOptMatch[1] : null;
      const correctId = correctOptMatch ? correctOptMatch[1] : null;

      let status: 'correct' | 'wrong' | 'unattempted' = 'unattempted';
      if (isNotAttempted || !givenId) {
        status = 'unattempted';
      } else if (givenId && correctId && givenId === correctId) {
        status = 'correct';
      } else {
        status = 'wrong';
      }

      questions.push({
        questionNumber: qIndex++,
        candidateAnswer: isNotAttempted ? 'Not Attempted' : givenId || '--',
        correctAnswer: correctId || undefined,
        status,
        marks: status === 'correct' ? 1.0 : status === 'wrong' ? -0.25 : 0,
      });
    }

    // =========================================================================
    // Parser Engine 2: TCS iON Format (.question-pnl, menu-tbl, Chosen Option, rightAns)
    // =========================================================================
    if (questions.length === 0) {
      const questionPanels = doc.querySelectorAll('.question-pnl, .questionPnl, .section-cnt, table.question, div.question, .questionRowTbl');

      if (questionPanels.length > 0) {
        questionPanels.forEach((panel, qIdx) => {
          const pText = panel.textContent || '';

          // Extract chosen option
          let chosenOption: string | null = null;
          const chosenMatch = pText.match(/(?:Chosen\s*Option|Given\s*Answer|Candidate\s*Option|दिया\s*गया\s*विकल्प)[\s:]*([0-9]+|--|[A-Da-d])/i);
          if (chosenMatch) {
            chosenOption = chosenMatch[1].trim();
          }

          const isNotAnswered =
            pText.includes('Not Answered') ||
            pText.includes('नॉट आंसर्ड') ||
            pText.includes('Not Attempted') ||
            chosenOption === '--' ||
            !chosenOption;

          let correctOptionIndex = -1;
          const optionRows = panel.querySelectorAll('.questionRowTbl tr, tr.questionRow, .option-tbl tr, table tr');

          if (optionRows.length > 0) {
            optionRows.forEach((row, oIdx) => {
              const hasRightClass =
                row.classList.contains('rightAns') ||
                row.querySelector('.rightAns') !== null ||
                row.querySelector('img[src*="correct"], img[src*="tick"], img[src*="right"]') !== null;
              const styleAttr = row.getAttribute('style') || '';
              const isGreenBg =
                styleAttr.includes('#71C387') ||
                styleAttr.includes('green') ||
                styleAttr.includes('#5cb85c') ||
                styleAttr.includes('rgb(113, 195, 135)') ||
                styleAttr.includes('#dff0d8');

              if (hasRightClass || isGreenBg) {
                correctOptionIndex = oIdx + 1;
              }
            });
          }

          if (correctOptionIndex === -1) {
            const correctTextMatch = pText.match(/(?:Right\s*Option|Correct\s*Option|सही\s*विकल्प)[\s:]*([1-4]|[A-D])/i);
            if (correctTextMatch) {
              const val = correctTextMatch[1];
              correctOptionIndex = isNaN(parseInt(val, 10)) ? val.toUpperCase().charCodeAt(0) - 64 : parseInt(val, 10);
            }
          }

          let status: 'correct' | 'wrong' | 'unattempted' = 'unattempted';

          if (isNotAnswered || !chosenOption) {
            status = 'unattempted';
          } else {
            let chosenNum = parseInt(chosenOption, 10);
            if (isNaN(chosenNum) && chosenOption.length === 1) {
              chosenNum = chosenOption.toUpperCase().charCodeAt(0) - 64;
            }

            if (correctOptionIndex !== -1 && !isNaN(chosenNum)) {
              status = chosenNum === correctOptionIndex ? 'correct' : 'wrong';
            } else {
              if (pText.includes('Right Answer') || pText.includes('Correct')) {
                status = 'correct';
              } else {
                status = 'wrong';
              }
            }
          }

          questions.push({
            questionNumber: qIdx + 1,
            candidateAnswer: chosenOption || '--',
            correctAnswer: correctOptionIndex !== -1 ? String(correctOptionIndex) : undefined,
            status,
            marks: status === 'correct' ? 1.0 : status === 'wrong' ? -0.25 : 0,
          });
        });
      }
    }

    // =========================================================================
    // Parser Engine 3: Explicit Score Summary in sheet (if summary table exists)
    // =========================================================================
    let detectedCorrect = 0;
    let detectedWrong = 0;
    let detectedTotal = 200;

    const summaryMatch =
      allText.match(/(?:Correct|सही\s*उत्तर)[\s:-]+(\d{1,3})[\s\S]*?(?:Wrong|Incorrect|गलत\s*उत्तर)[\s:-]+(\d{1,3})/i) ||
      allText.match(/Total\s*Questions[\s:-]+(\d{2,3})[\s\S]*?Attempted[\s:-]+(\d{1,3})[\s\S]*?Correct[\s:-]+(\d{1,3})/i);

    if (questions.length === 0 && summaryMatch) {
      if (summaryMatch.length === 3) {
        detectedCorrect = parseInt(summaryMatch[1], 10);
        detectedWrong = parseInt(summaryMatch[2], 10);
      } else if (summaryMatch.length === 4) {
        detectedTotal = parseInt(summaryMatch[1], 10);
        detectedCorrect = parseInt(summaryMatch[3], 10);
        const attempted = parseInt(summaryMatch[2], 10);
        detectedWrong = Math.max(0, attempted - detectedCorrect);
      }

      // Synthesize questions array to match summary
      for (let i = 1; i <= detectedTotal; i++) {
        let status: 'correct' | 'wrong' | 'unattempted' = 'unattempted';
        if (i <= detectedCorrect) status = 'correct';
        else if (i <= detectedCorrect + detectedWrong) status = 'wrong';

        questions.push({
          questionNumber: i,
          candidateAnswer: status === 'correct' ? 'Option 1' : status === 'wrong' ? 'Option 2' : 'Not Attempted',
          correctAnswer: 'Option 1',
          status,
          marks: status === 'correct' ? 1.0 : status === 'wrong' ? -0.25 : 0,
        });
      }
    }

    // Summary calculation
    const totalQuestions = questions.length > 0 ? questions.length : 200;
    const correct = questions.filter((q) => q.status === 'correct').length;
    const wrong = questions.filter((q) => q.status === 'wrong').length;
    const attempted = correct + wrong;
    const unattempted = Math.max(0, totalQuestions - attempted);

    const scoreData = calculateRawScore(correct, wrong, totalQuestions);
    const hasCandidateInfo = Boolean(rollNumber && rollNumber.length >= 6);

    return {
      candidateName:
        candidateName ||
        (fileName ? fileName.replace(/\.(mhtml|html|htm|mht|txt)$/i, '').toUpperCase() : 'परीक्षार्थी'),
      rollNumber: rollNumber || '',
      examDate: finalDate,
      shiftNumber,
      shiftId: `shift-${String(shiftNumber).padStart(2, '0')}`,
      totalQuestions,
      attempted,
      unattempted,
      correct,
      wrong,
      rawScore: scoreData.rawScore,
      accuracy: scoreData.accuracy,
      confidence: hasCandidateInfo && questions.length > 0 ? 'VERIFIED' : 'WARNING',
      questions,
      sourceFormat: rawContent.includes('cbtexam.in')
        ? 'MPESB_CBT_RESPONSE_SHEET'
        : rawContent.includes('MIME-Version')
        ? 'MHTML_PARSED'
        : 'HTML_PARSED',
      notes:
        questions.length === 0
          ? 'प्रश्नों की स्वचालित गणना हेतु आप नीचे सही और गलत प्रश्नों की संख्या की पुष्टि या संपादन कर सकते हैं।'
          : undefined,
    };
  }
}
