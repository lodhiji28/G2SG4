import React, { useState, useMemo } from 'react';
import { OFFICIAL_VACANCIES, MASTER_QUALIFICATIONS } from '../data/vacancies';
import { CandidateRecord } from '../types';
import { RawMarksDisclaimer } from './RawMarksDisclaimer';
import { 
  Briefcase, 
  Search, 
  Filter, 
  Users, 
  ExternalLink, 
  BookOpen, 
  CheckCircle,
  FileCheck2
} from 'lucide-react';

interface VacanciesViewProps {
  candidates: CandidateRecord[];
}

export const VacanciesView: React.FC<VacanciesViewProps> = ({ candidates }) => {
  const [search, setSearch] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedQual, setSelectedQual] = useState<string>('all');

  // Extract unique departments
  const departments = useMemo(() => {
    const set = new Set<string>();
    OFFICIAL_VACANCIES.forEach((v) => set.add(v.department));
    return Array.from(set);
  }, []);

  // Filtered vacancies
  const filtered = useMemo(() => {
    return OFFICIAL_VACANCIES.filter((v) => {
      if (selectedDept !== 'all' && v.department !== selectedDept) return false;
      if (selectedType !== 'all' && v.type !== selectedType) return false;
      if (selectedQual !== 'all' && !v.qualificationsRequired.includes(selectedQual)) return false;
      if (search) {
        const q = search.toLowerCase().trim();
        const matchesCode = v.postCode.toLowerCase().includes(q);
        const matchesName = v.postName.toLowerCase().includes(q);
        const matchesDept = v.department.toLowerCase().includes(q);
        if (!matchesCode && !matchesName && !matchesDept) return false;
      }
      return true;
    });
  }, [search, selectedDept, selectedType, selectedQual]);

  // Total vacancies in database
  const totalPostsCount = OFFICIAL_VACANCIES.reduce((acc, v) => acc + v.totalVacancies, 0);

  return (
    <div className="space-y-6 pb-16 transition-colors">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
            <Briefcase className="w-6 h-6 text-amber-500 dark:text-amber-400" />
            <span>पद एवं रिक्तियां विवरण (Official Vacancy Database)</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            आधिकारिक MPESB Group-2 Sub-Group-4 नियमपुस्तिका (145 पृष्ठ) के अनुसार पद कोड 001 से 257 तक पद विवरण
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 px-3.5 py-1.5 rounded-lg text-xs font-mono shadow-xs text-slate-800 dark:text-slate-200">
          कुल पद: <strong className="text-amber-600 dark:text-amber-400 font-bold">{totalPostsCount}</strong> रिक्तियां
        </div>
      </div>

      <RawMarksDisclaimer />

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          {/* Search */}
          <div>
            <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
              पद खोजें (Post Code / Name)
            </label>
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-3 text-slate-400 dark:text-slate-500" />
              <input
                type="text"
                placeholder="पोस्ट कोड या नाम..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          {/* Department Filter */}
          <div>
            <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
              विभाग (Department)
            </label>
            <select
              value={selectedDept}
              onChange={(e) => setSelectedDept(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-amber-500 truncate"
            >
              <option value="all">सभी विभाग (All Departments)</option>
              {departments.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
          </div>

          {/* Executive Type Filter */}
          <div>
            <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
              संवर्ग (Type)
            </label>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-amber-500"
            >
              <option value="all">सभी संवर्ग (All)</option>
              <option value="कार्यपालिक">कार्यपालिक (Executive)</option>
              <option value="अकार्यपालिक">अकार्यपालिक (Non-Executive)</option>
            </select>
          </div>

          {/* Qualification Filter */}
          <div>
            <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">
              अनिवार्य योग्यता (Qualification)
            </label>
            <select
              value={selectedQual}
              onChange={(e) => setSelectedQual(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-amber-500 truncate"
            >
              <option value="all">सभी योग्यताएं</option>
              {MASTER_QUALIFICATIONS.map((q) => (
                <option key={q} value={q}>
                  {q}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Vacancy Cards & Grid */}
      <div className="space-y-4">
        {filtered.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center text-slate-500 dark:text-slate-400 text-xs shadow-xs">
            कोई पद रिकॉर्ड नहीं मिला। कृपया अपने फ़िल्टर बदलें।
          </div>
        ) : (
          filtered.map((post) => {
            // Count candidates in dataset who meet at least one qualification for this post
            const eligibleCandidatesInDataset = candidates.filter((c) =>
              post.qualificationsRequired.some((req) => c.qualifications?.includes(req))
            ).length;

            return (
              <div
                key={post.postCode}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs space-y-4 hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
              >
                {/* Header Row */}
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono font-bold text-amber-700 dark:text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded text-xs">
                        Post Code {post.postCode}
                      </span>
                      <span className="text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                        {post.type}
                      </span>
                      <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                        पृष्ठ सं. {post.sourcePage}
                      </span>
                    </div>

                    <h2 className="text-base font-bold text-slate-900 dark:text-white">
                      {post.postName}
                    </h2>

                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      विभाग: <strong className="text-slate-700 dark:text-slate-300">{post.department}</strong>
                    </p>
                  </div>

                  {/* Vacancy Count Badge */}
                  <div className="text-right">
                    <div className="text-xl font-black font-mono text-slate-900 dark:text-white tabular-nums">
                      {post.totalVacancies} <span className="text-xs font-normal text-slate-500 dark:text-slate-400">पद</span>
                    </div>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">{post.payScale}</span>
                  </div>
                </div>

                {/* Category Breakdown Table */}
                <div className="grid grid-cols-6 gap-2 bg-slate-50 dark:bg-slate-950 p-3 rounded-lg border border-slate-200 dark:border-slate-800/80 text-center text-xs font-mono">
                  <div>
                    <span className="text-[10px] text-slate-500 block font-sans">UR (अनारक्षित)</span>
                    <span className="font-bold text-slate-900 dark:text-white">{post.categoryBreakdown.UR}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block font-sans">EWS</span>
                    <span className="font-bold text-slate-700 dark:text-slate-300">{post.categoryBreakdown.EWS}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block font-sans">SC</span>
                    <span className="font-bold text-slate-700 dark:text-slate-300">{post.categoryBreakdown.SC}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block font-sans">ST</span>
                    <span className="font-bold text-slate-700 dark:text-slate-300">{post.categoryBreakdown.ST}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block font-sans">OBC</span>
                    <span className="font-bold text-amber-600 dark:text-amber-400">{post.categoryBreakdown.OBC}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400 block font-sans">कुल (Total)</span>
                    <span className="font-bold text-emerald-600 dark:text-emerald-300">{post.totalVacancies}</span>
                  </div>
                </div>

                {/* Qualification Details */}
                <div className="space-y-1.5 text-xs">
                  <div className="text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400" />
                    <span className="font-medium text-slate-700 dark:text-slate-300">अनिवार्य शैक्षणिक अहर्ता:</span>
                  </div>
                  <p className="text-slate-700 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-950/40 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800/60">
                    {post.qualificationSummary}
                  </p>
                </div>

                {/* Vacancy vs Competition Pool Indicator (Blueprint #32) */}
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex flex-wrap items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span className="flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
                    <span>Rank Mitra डेटासेट में पात्र उम्मीदवार:</span>
                    <strong className="text-slate-900 dark:text-white font-mono">{eligibleCandidatesInDataset}</strong>
                  </span>
                  <span className="text-[11px] text-slate-400 dark:text-slate-500">
                    (संकेतात्मक विश्लेषण · आधिकारिक रोस्टर लागू होगा)
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
