import React, { useState } from 'react';
import { CandidateRecord, ShiftStats, AuditLog } from '../types';
import { getAuditLogs, addAuditLog, clearAllCandidates } from '../lib/storage';
import { EXAM_SHIFTS } from '../data/shifts';
import { 
  Shield, 
  Lock, 
  Download, 
  Search, 
  Trash2, 
  LogOut,
  AlertTriangle
} from 'lucide-react';

interface AdminViewProps {
  candidates: CandidateRecord[];
  shiftStats: ShiftStats[];
  onRefreshData: () => void;
}

export const AdminView: React.FC<AdminViewProps> = ({
  candidates,
  shiftStats,
  onRefreshData,
}) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [passwordInput, setPasswordInput] = useState<string>('');
  const [authError, setAuthError] = useState<string | null>(null);

  // Search & filter in admin
  const [search, setSearch] = useState<string>('');
  const [shiftFilter, setShiftFilter] = useState<string>('all');
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(getAuditLogs());
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    if (passwordInput === 'admin123' || passwordInput === 'admin@mpesb') {
      setIsAuthenticated(true);
      addAuditLog('ADMIN_LOGIN', 'Administrator signed into session', 'Admin');
      setAuditLogs(getAuditLogs());
    } else {
      setAuthError('गलत पासवर्ड। कृपया सही अधिकृत पासवर्ड दर्ज करें।');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setPasswordInput('');
    addAuditLog('ADMIN_LOGOUT', 'Administrator signed out', 'Admin');
  };

  const handleClearAllData = () => {
    clearAllCandidates();
    onRefreshData();
    setShowResetConfirm(false);
    setAuditLogs(getAuditLogs());
  };

  // Export to CSV
  const handleExportCSV = () => {
    const headers = [
      'Roll Number',
      'Candidate Name',
      'Exam Date',
      'Shift Number',
      'Category',
      'Gender',
      'Total Questions',
      'Attempted',
      'Correct',
      'Wrong',
      'Raw Score',
      'Accuracy %',
      'Qualifications',
      'Ex-Serviceman',
      'Contract',
      'Submitted At',
    ];

    const rows = candidates.map((c) => [
      c.rollNumber,
      `"${c.candidateNamePrivate}"`,
      c.examDate,
      c.shiftNumber,
      c.category,
      c.gender,
      c.totalQuestions,
      c.attempted,
      c.correct,
      c.wrong,
      c.rawScore,
      c.accuracy,
      `"${c.qualifications.join('; ')}"`,
      c.exServiceman ? 'Yes' : 'No',
      c.contractStatus ? 'Yes' : 'No',
      c.submittedAt,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `rank_mitra_mpesb_g2sg4_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    addAuditLog('EXPORT_CSV', `Exported ${candidates.length} candidates to CSV`, 'Admin');
    setAuditLogs(getAuditLogs());
  };

  // Export to JSON
  const handleExportJSON = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(candidates, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `rank_mitra_dataset_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();

    addAuditLog('EXPORT_JSON', `Exported ${candidates.length} candidates to JSON`, 'Admin');
    setAuditLogs(getAuditLogs());
  };

  // Filtered candidate list
  const filteredCandidates = candidates.filter((c) => {
    if (shiftFilter !== 'all' && c.shiftNumber !== parseInt(shiftFilter, 10)) return false;
    if (search) {
      const q = search.toLowerCase();
      const matchRoll = c.rollNumber.toLowerCase().includes(q);
      const matchName = c.candidateNamePrivate.toLowerCase().includes(q);
      if (!matchRoll && !matchName) return false;
    }
    return true;
  });

  // If not authenticated, render login form
  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto py-16 px-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6 shadow-xl">
          <div className="text-center space-y-2">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto">
              <Shield className="w-6 h-6" />
            </div>
            <h1 className="text-xl font-bold text-slate-900 dark:text-white">प्रशासक लॉगिन (Admin Login)</h1>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              डेटा प्रबंधन, ऑडिट लॉग्स और पूर्ण डेटासेट निर्यात हेतु अधिकृत पासवर्ड दर्ज करें।
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                प्रशासक पासवर्ड (Admin Password)
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 absolute left-3 top-3 text-slate-400 dark:text-slate-500" />
                <input
                  type="password"
                  placeholder="सुरक्षित पासवर्ड दर्ज करें..."
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-xl pl-9 pr-3 py-2.5 text-xs text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-amber-500 font-medium"
                />
              </div>
            </div>

            {authError && (
              <p className="text-xs text-rose-600 dark:text-rose-400 font-medium">{authError}</p>
            )}

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition-all cursor-pointer"
            >
              लॉगिन करें
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-16 transition-colors">
      {/* Admin Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-lg font-bold text-slate-900 dark:text-white">प्रशासक कंसोल (Admin Management Console)</h1>
            <p className="text-xs text-slate-600 dark:text-slate-400">
              डेटा गुणवत्ता सत्यापन · CSV/JSON निर्यात · ऑडिट लॉग्स · उम्मीदवार प्रबंधन
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>CSV निर्यात</span>
          </button>

          <button
            onClick={handleExportJSON}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-medium border border-slate-300 dark:border-slate-700 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>JSON निर्यात</span>
          </button>

          <button
            onClick={() => setShowResetConfirm(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-100 dark:bg-rose-500/10 dark:text-rose-300 dark:hover:bg-rose-500/20 border border-rose-200 dark:border-rose-500/30 text-xs font-medium transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>डेटा रीसेट करें</span>
          </button>

          <button
            onClick={handleLogout}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 text-xs font-medium transition-colors cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>लॉगआउट</span>
          </button>
        </div>
      </div>

      {/* Reset Confirmation Dialog */}
      {showResetConfirm && (
        <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800 text-rose-900 dark:text-rose-200 text-xs space-y-2">
          <div className="flex items-center gap-2 font-bold text-sm">
            <AlertTriangle className="w-4 h-4 text-rose-600 dark:text-rose-400" />
            <span>क्या आप सभी सबमिशन डेटा साफ़ (Reset) करना चाहते हैं?</span>
          </div>
          <p>
            इस क्रिया से स्थानीय स्तर पर जमा किए गए सभी उम्मीदवार रिकॉर्ड मिटा दिए जाएंगे और डेटा शून्य हो जाएगा।
          </p>
          <div className="flex items-center gap-2 pt-1">
            <button
              onClick={handleClearAllData}
              className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs cursor-pointer"
            >
              हाँ, सारा डेटा साफ़ करें
            </button>
            <button
              onClick={() => setShowResetConfirm(false)}
              className="px-3 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs cursor-pointer"
            >
              रद्द करें
            </button>
          </div>
        </div>
      )}

      {/* Admin KPIs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-xl shadow-xs">
          <span className="text-xs text-slate-500 dark:text-slate-400 block font-medium">कुल पंजीकृत उम्मीदवार</span>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white mt-1 tabular-nums">
            {candidates.length}
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-xl shadow-xs">
          <span className="text-xs text-slate-500 dark:text-slate-400 block font-medium">कुल परीक्षा शिफ्ट्स</span>
          <div className="text-2xl font-bold font-mono text-amber-600 dark:text-amber-400 mt-1 tabular-nums">
            22 Shifts
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-xl shadow-xs">
          <span className="text-xs text-slate-500 dark:text-slate-400 block font-medium">पार्सिंग सटीकता दर</span>
          <div className="text-2xl font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-1 tabular-nums">
            100%
          </div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-xl shadow-xs">
          <span className="text-xs text-slate-500 dark:text-slate-400 block font-medium">डुप्लीकेट सुरक्षा</span>
          <div className="text-2xl font-bold font-mono text-cyan-600 dark:text-cyan-400 mt-1">
            सक्रिय
          </div>
        </div>
      </div>

      {/* Candidate Records Search & Management */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs space-y-3 p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-white">
            उम्मीदवार रिकॉर्ड्स (Candidate Records - Unmasked Admin View)
          </h2>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400 dark:text-slate-500" />
              <input
                type="text"
                placeholder="रोल या नाम खोजें..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg pl-8 pr-3 py-1 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-amber-500"
              />
            </div>
            <select
              value={shiftFilter}
              onChange={(e) => setShiftFilter(e.target.value)}
              className="bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg px-2.5 py-1 text-xs text-slate-900 dark:text-white focus:outline-none"
            >
              <option value="all">सभी 22 शिफ्ट्स</option>
              {EXAM_SHIFTS.map((s) => (
                <option key={s.id} value={s.shiftNumber}>
                  Shift {s.shiftNumber} ({s.displayDate})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="overflow-x-auto max-h-96">
          <table className="w-full text-left text-xs text-slate-700 dark:text-slate-300">
            <thead className="bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400 font-semibold border-b border-slate-200 dark:border-slate-800 uppercase text-[11px] sticky top-0">
              <tr>
                <th className="py-2.5 px-3">रोल नंबर</th>
                <th className="py-2.5 px-3">पूरा नाम (Private Name)</th>
                <th className="py-2.5 px-3">शिफ्ट व दिनांक</th>
                <th className="py-2.5 px-3">श्रेणी</th>
                <th className="py-2.5 px-3">लिंग</th>
                <th className="py-2.5 px-3 text-right">सही</th>
                <th className="py-2.5 px-3 text-right">गलत</th>
                <th className="py-2.5 px-3 text-right text-amber-600 dark:text-amber-400 font-bold">रॉ स्कोर</th>
                <th className="py-2.5 px-3">योग्यताएं</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono text-[11px]">
              {filteredCandidates.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-6 text-center text-slate-500 font-sans">
                    कोई उम्मीदवार रिकॉर्ड उपलब्ध नहीं है।
                  </td>
                </tr>
              ) : (
                filteredCandidates.slice(0, 50).map((c) => (
                  <tr key={c.rollNumber} className="hover:bg-slate-50 dark:hover:bg-slate-850">
                    <td className="py-2 px-3 text-slate-900 dark:text-white font-semibold">{c.rollNumber}</td>
                    <td className="py-2 px-3 font-sans text-slate-800 dark:text-slate-200">{c.candidateNamePrivate}</td>
                    <td className="py-2 px-3 font-sans text-slate-600 dark:text-slate-400">Shift {c.shiftNumber} ({c.examDate})</td>
                    <td className="py-2 px-3 font-sans text-slate-700 dark:text-slate-300">{c.category}</td>
                    <td className="py-2 px-3 font-sans text-slate-600 dark:text-slate-400">{c.gender}</td>
                    <td className="py-2 px-3 text-right text-emerald-600 dark:text-emerald-400">{c.correct}</td>
                    <td className="py-2 px-3 text-right text-rose-600 dark:text-rose-400">{c.wrong}</td>
                    <td className="py-2 px-3 text-right text-amber-600 dark:text-amber-400 font-bold text-xs">{c.rawScore}</td>
                    <td className="py-2 px-3 font-sans text-slate-600 dark:text-slate-400 truncate max-w-[150px]">
                      {c.qualifications.join(', ')}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        <div className="text-[11px] text-slate-500 dark:text-slate-400 text-right pt-1">
          दर्शाए जा रहे हैं {Math.min(50, filteredCandidates.length)} / {filteredCandidates.length} रिकॉर्ड्स
        </div>
      </div>

      {/* Audit Log Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs space-y-3">
        <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
          सिस्टम ऑडिट लॉग्स (System Audit Trail)
        </h3>
        <div className="space-y-1.5 max-h-48 overflow-y-auto font-mono text-[11px]">
          {auditLogs.length === 0 ? (
            <p className="text-slate-500 font-sans">कोई लॉग उपलब्ध नहीं है।</p>
          ) : (
            auditLogs.map((log) => (
              <div key={log.id} className="p-2 rounded bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 flex items-center justify-between">
                <div>
                  <span className="text-amber-600 dark:text-amber-400 font-semibold">[{log.action}]</span>{' '}
                  <span className="text-slate-700 dark:text-slate-300">{log.details}</span>
                </div>
                <span className="text-slate-500 text-[10px]">
                  {new Date(log.timestamp).toLocaleTimeString()}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
