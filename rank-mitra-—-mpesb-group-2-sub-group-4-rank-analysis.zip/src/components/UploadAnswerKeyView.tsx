import React, { useState, useRef } from 'react';
import { AnswerKeyParser } from '../lib/parser';
import { ParsedAnswerKeyData, Category, Gender, CandidateRecord } from '../types';
import { MASTER_QUALIFICATIONS } from '../data/vacancies';
import { EXAM_SHIFTS } from '../data/shifts';
import { calculateRawScore } from '../lib/scoring';
import { addCandidateSubmission } from '../lib/storage';
import { 
  Upload, 
  FileText, 
  CheckCircle, 
  AlertCircle, 
  ChevronRight, 
  Calendar, 
  ShieldCheck,
  FileCode,
  Sparkles,
  RefreshCw,
  Info
} from 'lucide-react';

interface UploadAnswerKeyViewProps {
  onSubmissionSuccess: (rollNumber: string) => void;
}

export const UploadAnswerKeyView: React.FC<UploadAnswerKeyViewProps> = ({
  onSubmissionSuccess,
}) => {
  // Input method tab: 'file' or 'paste'
  const [inputTab, setInputTab] = useState<'file' | 'paste'>('file');
  const [pastedCode, setPastedCode] = useState<string>('');

  const [file, setFile] = useState<File | null>(null);
  const [parsing, setParsing] = useState(false);
  const [parseError, setParseError] = useState<string | null>(null);
  const [parsedData, setParsedData] = useState<ParsedAnswerKeyData | null>(null);

  // Review & Confirmation editable fields
  const [editName, setEditName] = useState<string>('');
  const [editRoll, setEditRoll] = useState<string>('');
  const [editDate, setEditDate] = useState<string>('23/09/2026');
  const [editShiftNumber, setEditShiftNumber] = useState<number>(1);
  const [editCorrect, setEditCorrect] = useState<number>(0);
  const [editWrong, setEditWrong] = useState<number>(0);
  const [editTotalQuestions, setEditTotalQuestions] = useState<number>(200);

  // Demographics
  const [category, setCategory] = useState<Category>('UR');
  const [gender, setGender] = useState<Gender>('Male');
  const [selectedQualifications, setSelectedQualifications] = useState<string[]>([
    'स्नातक (Graduation in any discipline)',
    'CPCT स्कोर कार्ड (हिंदी टाइपिंग)',
  ]);
  const [isExServiceman, setIsExServiceman] = useState<boolean>(false);
  const [isContractWorker, setIsContractWorker] = useState<boolean>(false);

  // Submission state
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selected = e.target.files?.[0];
    if (selected) {
      processSelectedFile(selected);
    }
  };

  const processSelectedFile = (selectedFile: File) => {
    setParseError(null);
    setSubmitError(null);
    setFile(selectedFile);
    setParsing(true);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parser = new AnswerKeyParser();
        const extracted = parser.parse(content, selectedFile.name);
        applyExtractedData(extracted);
      } catch (err: any) {
        setParseError(
          err.message || 'फ़ाइल से डेटा निकालने में त्रुटि हुई। आप सीधे "कोड पेस्ट करें" विकल्प से भी डेटा दर्ज कर सकते हैं।'
        );
      } finally {
        setParsing(false);
      }
    };

    reader.onerror = () => {
      setParseError('फ़ाइल पढ़ने में त्रुटि। कृपया पुनः प्रयास करें या सीधे टेक्स्ट पेस्ट करें।');
      setParsing(false);
    };

    reader.readAsText(selectedFile);
  };

  const handleProcessPastedText = () => {
    if (!pastedCode || pastedCode.trim().length === 0) {
      setParseError('कृपया पहले HTML या MHTML कोड या टेक्स्ट पेस्ट करें।');
      return;
    }

    setParseError(null);
    setSubmitError(null);
    setParsing(true);

    try {
      const parser = new AnswerKeyParser();
      const extracted = parser.parse(pastedCode, 'PASTED_CODE.html');
      applyExtractedData(extracted);
    } catch (err: any) {
      setParseError(
        err.message || 'पेस्ट किए गए कोड से डेटा नहीं निकाला जा सका। कृपया सुनिश्चित करें कि यह सही उत्तर कुंजी है।'
      );
    } finally {
      setParsing(false);
    }
  };

  const applyExtractedData = (extracted: ParsedAnswerKeyData) => {
    setParsedData(extracted);
    setEditName(extracted.candidateName || '');
    setEditRoll(extracted.rollNumber || '');
    setEditDate(extracted.examDate || '23/09/2026');
    setEditShiftNumber(extracted.shiftNumber || 1);
    setEditCorrect(extracted.correct || 0);
    setEditWrong(extracted.wrong || 0);
    setEditTotalQuestions(extracted.totalQuestions || 200);
  };

  // Recalculate score live when user edits numbers in review
  const liveScoreData = calculateRawScore(
    editCorrect,
    editWrong,
    editTotalQuestions
  );

  const toggleQualification = (qual: string) => {
    if (selectedQualifications.includes(qual)) {
      setSelectedQualifications(selectedQualifications.filter((q) => q !== qual));
    } else {
      setSelectedQualifications([...selectedQualifications, qual]);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitError(null);

    if (!parsedData) {
      setSubmitError('कृपया पहले अपनी उत्तर कुंजी (Answer Key) फ़ाइल अपलोड करें या कोड पेस्ट करें।');
      return;
    }

    const finalRoll = editRoll.trim();
    if (!finalRoll) {
      setSubmitError('कृपया अपना रोल नंबर (Roll Number) दर्ज करें। यह अनिवार्य है।');
      return;
    }

    if (!category) {
      setSubmitError('कृपया अपनी आरक्षण श्रेणी (Category) का चयन करें। यह अनिवार्य है।');
      return;
    }

    if (!gender) {
      setSubmitError('कृपया अपने लिंग (Gender) का चयन करें। यह अनिवार्य है।');
      return;
    }

    setSubmitting(true);

    try {
      const selectedShiftObj = EXAM_SHIFTS.find((s) => s.shiftNumber === editShiftNumber);
      const shiftDateFormatted = selectedShiftObj ? selectedShiftObj.displayDate : editDate;

      // Mask candidate name for privacy
      const finalName = editName.trim() || 'अभ्यर्थी';
      const nameParts = finalName.split(/\s+/);
      const publicName =
        nameParts.length > 1
          ? `${nameParts[0]} ${nameParts[1].charAt(0).toUpperCase()}****`
          : `${finalName.slice(0, 3)}•••`;

      const candidateSubmission: CandidateRecord = {
        id: `cand-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        examId: 'mpesb-g2sg4-2026',
        rollNumber: finalRoll,
        candidateNamePrivate: finalName,
        candidateNamePublic: publicName,
        examDate: shiftDateFormatted,
        shiftNumber: editShiftNumber,
        shiftId: `shift-${String(editShiftNumber).padStart(2, '0')}`,
        category,
        gender,
        totalQuestions: editTotalQuestions,
        attempted: liveScoreData.attempted,
        unattempted: liveScoreData.unattempted,
        correct: liveScoreData.correct,
        wrong: liveScoreData.wrong,
        rawScore: liveScoreData.rawScore,
        accuracy: liveScoreData.accuracy,
        exServiceman: isExServiceman,
        contractStatus: isContractWorker,
        qualifications: selectedQualifications,
        submittedAt: new Date().toISOString(),
      };

      const result = addCandidateSubmission(candidateSubmission);

      if (!result.success) {
        setSubmitError(result.error || 'सबमिशन विफल रहा।');
        setSubmitting(false);
        return;
      }

      onSubmissionSuccess(candidateSubmission.rollNumber);
    } catch (err: any) {
      setSubmitError(err.message || 'त्रुटि हुई। कृपया पुनः प्रयास करें।');
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-16 transition-colors">
      {/* Header Banner */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xs">
        <div className="max-w-2xl space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-700 dark:text-amber-400 text-xs font-semibold">
            <ShieldCheck className="w-4 h-4" />
            <span>100% सुरक्षित एवं निजी रॉ मार्क्स विश्लेषण</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            अपनी उत्तर कुंजी (Answer Key) अपलोड करें
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            MPESB Group-2 Sub-Group-4 परीक्षा की HTML या MHTML फ़ाइल चुनें अथवा कोड पेस्ट करें। सिस्टम स्वचालित रूप से आपके सही, गलत प्रश्न और 22 शिफ्ट्स में आपकी लाइव रैंक निकालेगा।
          </p>
        </div>
      </div>

      {/* Upload & Input Methods Selector */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs space-y-6">
        <div className="flex border-b border-slate-200 dark:border-slate-800 gap-4 text-xs font-bold">
          <button
            type="button"
            onClick={() => setInputTab('file')}
            className={`pb-3 border-b-2 flex items-center gap-2 transition-colors cursor-pointer ${
              inputTab === 'file'
                ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
            }`}
          >
            <Upload className="w-4 h-4" />
            <span>फ़ाइल अपलोड करें (HTML / MHTML)</span>
          </button>
          <button
            type="button"
            onClick={() => setInputTab('paste')}
            className={`pb-3 border-b-2 flex items-center gap-2 transition-colors cursor-pointer ${
              inputTab === 'paste'
                ? 'border-amber-500 text-amber-600 dark:text-amber-400'
                : 'border-transparent text-slate-500 hover:text-slate-700 dark:hover:text-slate-300'
            }`}
          >
            <FileCode className="w-4 h-4" />
            <span>सीधे कोड पेस्ट करें (Paste Code)</span>
          </button>
        </div>

        {/* Tab 1: File Dropzone */}
        {inputTab === 'file' && (
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-amber-500 dark:hover:border-amber-500 rounded-2xl p-8 sm:p-12 text-center cursor-pointer bg-slate-50/60 dark:bg-slate-950/40 transition-all group"
          >
            <input
              ref={fileInputRef}
              type="file"
              accept=".html,.htm,.mhtml,.mht,.txt,text/html,multipart/related,message/rfc822,*/*"
              onChange={handleFileChange}
              className="hidden"
            />
            <div className="w-16 h-16 rounded-2xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto mb-4 group-hover:scale-105 transition-transform">
              <Upload className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              {file ? file.name : 'उत्तर कुंजी फ़ाइल यहाँ चुनें या ड्रैग करें'}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 max-w-sm mx-auto">
              MPESB या TCS iON से डाउनलोड की गई .html, .htm, .mhtml या .mht फ़ाइल का चयन करें
            </p>
            <div className="mt-4">
              <span className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-xs transition-colors">
                <FileText className="w-4 h-4" />
                <span>फ़ाइल ब्राउज़ करें (Browse Files)</span>
              </span>
            </div>
          </div>
        )}

        {/* Tab 2: Direct Paste Textarea */}
        {inputTab === 'paste' && (
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                HTML या MHTML कोड / रिस्पांस शीट का टेक्स्ट यहाँ पेस्ट करें:
              </label>
              <textarea
                rows={8}
                value={pastedCode}
                onChange={(e) => setPastedCode(e.target.value)}
                placeholder="ब्राउज़र में अपनी उत्तर कुंजी खोलें -> Right Click -> View Page Source (या Ctrl+U) -> Ctrl+A (सभी कॉपी करें) -> यहाँ पेस्ट करें (Ctrl+V)..."
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-3.5 text-xs font-mono text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-600 focus:outline-none focus:border-amber-500"
              />
            </div>
            <button
              type="button"
              onClick={handleProcessPastedText}
              disabled={parsing || !pastedCode.trim()}
              className="px-6 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 font-bold text-xs shadow-xs transition-colors flex items-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>{parsing ? 'डेटा निकाला जा रहा है...' : 'डेटा निकालें और सत्यापित करें (Extract Data)'}</span>
            </button>
          </div>
        )}

        {/* Parsing Indicator */}
        {parsing && (
          <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-800 dark:text-amber-300 flex items-center gap-3 text-xs">
            <RefreshCw className="w-4 h-4 animate-spin text-amber-500 shrink-0" />
            <span>फ़ाइल का विश्लेषण व प्रश्नों की गणना की जा रही है, कृपया प्रतीक्षा करें...</span>
          </div>
        )}

        {/* Parse Error Notice */}
        {parseError && (
          <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/20 border border-rose-300 dark:border-rose-500/30 text-rose-800 dark:text-rose-300 flex items-start gap-3 text-xs">
            <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">त्रुटि: {parseError}</p>
              <p className="mt-1 text-[11px] text-rose-700 dark:text-rose-400">
                सुझाव: यदि फ़ाइल अपलोड में समस्या आ रही है, तो आप ऊपर दिए गए <strong>"सीधे कोड पेस्ट करें"</strong> टैब का उपयोग कर सकते हैं।
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Review, Verification & Submission Form */}
      {parsedData && (
        <form onSubmit={handleSubmit} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-500" />
                <span>निकाला गया डेटा (Review & Confirm)</span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                कृपया नीचे दी गई जानकारी की पुष्टि करें। आप आवश्यकतानुसार फ़ील्ड्स को संपादित कर सकते हैं।
              </p>
            </div>
            <div className="px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-700 dark:text-emerald-400 text-xs font-bold font-mono">
              रॉ स्कोर: {liveScoreData.rawScore} / 200
            </div>
          </div>

          {/* Quick Score Snapshot Box */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-200 dark:border-slate-800 text-center font-mono text-xs">
            <div>
              <span className="text-[11px] text-slate-500 font-sans block">सही प्रश्न (+1.0)</span>
              <span className="text-lg font-bold text-emerald-600 dark:text-emerald-400">{liveScoreData.correct}</span>
            </div>
            <div>
              <span className="text-[11px] text-slate-500 font-sans block">गलत प्रश्न (-0.25)</span>
              <span className="text-lg font-bold text-rose-600 dark:text-rose-400">{liveScoreData.wrong}</span>
            </div>
            <div>
              <span className="text-[11px] text-slate-500 font-sans block">कुल प्रयास (Attempted)</span>
              <span className="text-lg font-bold text-slate-900 dark:text-white">{liveScoreData.attempted}</span>
            </div>
            <div>
              <span className="text-[11px] text-slate-500 font-sans block">सटीकता (Accuracy)</span>
              <span className="text-lg font-bold text-amber-600 dark:text-amber-400">{liveScoreData.accuracy}%</span>
            </div>
          </div>

          {/* Candidate Details Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            {/* Roll Number */}
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                रोल नंबर (Roll Number) <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                required
                value={editRoll}
                onChange={(e) => setEditRoll(e.target.value)}
                placeholder="रोल नंबर दर्ज करें (उदा. 2309101234)"
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-white font-mono font-medium focus:outline-none focus:border-amber-500"
              />
            </div>

            {/* Candidate Name */}
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                परीक्षार्थी का नाम (Candidate Name)
              </label>
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                placeholder="परीक्षार्थी का नाम दर्ज करें"
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl px-3.5 py-2.5 text-xs text-slate-900 dark:text-white font-medium focus:outline-none focus:border-amber-500"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">सार्वजनिक लीडरबोर्ड पर नाम स्वतः मास्क रहेगा।</span>
            </div>

            {/* Shift with Date Selection */}
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                परीक्षा शिफ्ट व दिनांक (Shift & Date) <span className="text-rose-500">*</span>
              </label>
              <select
                value={editShiftNumber}
                onChange={(e) => setEditShiftNumber(parseInt(e.target.value, 10))}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl px-3 py-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-amber-500"
              >
                {EXAM_SHIFTS.map((s) => (
                  <option key={s.shiftNumber} value={s.shiftNumber}>
                    Shift {s.shiftNumber} — {s.displayDate} ({s.shiftTime === 'Morning' ? 'प्रातः' : 'दोपहर'})
                  </option>
                ))}
              </select>
            </div>

            {/* Category */}
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                आरक्षण श्रेणी (Category) <span className="text-rose-500">*</span>
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as Category)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl px-3 py-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-amber-500 font-semibold"
              >
                <option value="UR">UR (अनारक्षित / सामान्य)</option>
                <option value="OBC">OBC (अन्य पिछड़ा वर्ग)</option>
                <option value="SC">SC (अनुसूचित जाति)</option>
                <option value="ST">ST (अनुसूचित जनजाति)</option>
                <option value="EWS">EWS (आर्थिक रूप से कमजोर)</option>
              </select>
            </div>

            {/* Gender */}
            <div>
              <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                लिंग (Gender) <span className="text-rose-500">*</span>
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(['Male', 'Female'] as Gender[]).map((g) => (
                  <button
                    key={g}
                    type="button"
                    onClick={() => setGender(g)}
                    className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                      gender === g
                        ? 'bg-amber-500/10 border-amber-500 text-amber-700 dark:text-amber-400'
                        : 'bg-slate-50 dark:bg-slate-950 border-slate-300 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {g === 'Male' ? 'पुरुष (Male)' : 'महिला (Female)'}
                  </button>
                ))}
              </div>
            </div>

            {/* Score Counts Editor */}
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  सही प्रश्न (Correct)
                </label>
                <input
                  type="number"
                  min={0}
                  max={200}
                  value={editCorrect}
                  onChange={(e) => setEditCorrect(Math.max(0, parseInt(e.target.value, 10) || 0))}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white font-mono font-bold focus:outline-none focus:border-amber-500"
                />
              </div>
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  गलत प्रश्न (Wrong)
                </label>
                <input
                  type="number"
                  min={0}
                  max={200}
                  value={editWrong}
                  onChange={(e) => setEditWrong(Math.max(0, parseInt(e.target.value, 10) || 0))}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-900 dark:text-white font-mono font-bold focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>
          </div>

          {/* Qualifications Checkboxes */}
          <div className="space-y-2 pt-2 border-t border-slate-200 dark:border-slate-800">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              शैक्षणिक योग्यताएं (Qualifications)
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {MASTER_QUALIFICATIONS.slice(0, 6).map((q) => (
                <label
                  key={q}
                  className="flex items-center gap-2 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-950/60 cursor-pointer text-xs text-slate-700 dark:text-slate-300"
                >
                  <input
                    type="checkbox"
                    checked={selectedQualifications.includes(q)}
                    onChange={() => toggleQualification(q)}
                    className="rounded border-slate-300 text-amber-500 focus:ring-amber-400"
                  />
                  <span className="truncate">{q}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Ex-Serviceman & Contract Workers */}
          <div className="flex flex-wrap gap-4 pt-2 border-t border-slate-200 dark:border-slate-800 text-xs">
            <label className="flex items-center gap-2 cursor-pointer text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={isExServiceman}
                onChange={(e) => setIsExServiceman(e.target.checked)}
                className="rounded border-slate-300 text-amber-500"
              />
              <span>भूतपूर्व सैनिक (Ex-Serviceman)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={isContractWorker}
                onChange={(e) => setIsContractWorker(e.target.checked)}
                className="rounded border-slate-300 text-amber-500"
              />
              <span>संविदा कर्मचारी (20% संविदा कोटा)</span>
            </label>
          </div>

          {/* Submit Error */}
          {submitError && (
            <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-300 dark:border-rose-500/40 text-rose-800 dark:text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
              <span>{submitError}</span>
            </div>
          )}

          {/* Submit CTA Button */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 font-extrabold text-sm shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{submitting ? 'सबमिट किया जा रहा है...' : 'सबमिट करें और अपनी लाइव रैंक देखें'}</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
