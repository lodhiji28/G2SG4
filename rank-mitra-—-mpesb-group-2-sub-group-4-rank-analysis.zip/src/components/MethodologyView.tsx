import React from 'react';
import { BookOpen, Calculator, ShieldCheck, CheckCircle2, AlertTriangle, FileCode } from 'lucide-react';
import { RawMarksDisclaimer } from './RawMarksDisclaimer';

export const MethodologyView: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-16 transition-colors">
      <div>
        <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight flex items-center gap-2">
          <BookOpen className="w-6 h-6 text-amber-500 dark:text-amber-400" />
          <span>रैंक व स्कोर गणना पद्धति (Scoring Methodology)</span>
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          MPESB Group-2 Sub-Group-4 परीक्षा के लिए गणितीय सूत्र, नियम और डेटा नीतियां
        </p>
      </div>

      <RawMarksDisclaimer />

      {/* 1. Raw Score Formula Card */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4 shadow-xs">
        <div className="flex items-center gap-2 text-amber-700 dark:text-amber-400 font-semibold text-sm">
          <Calculator className="w-5 h-5" />
          <span>रॉ स्कोर (Raw Score) का गणना सूत्र</span>
        </div>

        <div className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-4 rounded-xl font-mono text-center space-y-2">
          <div className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
            Raw Score = (Correct × 1.0) − (Wrong × 0.25)
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400 font-sans">
            प्रत्येक सही उत्तर हेतु <strong>+1.0 अंक</strong> तथा प्रत्येक गलत उत्तर हेतु <strong>-0.25 अंक</strong> (1/4 नेगेटिव मार्किंग)। अनुत्तरित (Unattempted) प्रश्नों पर कोई अंक नहीं काटा जाता।
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs pt-2">
          <div className="bg-slate-50 dark:bg-slate-950/60 p-3 rounded-lg border border-slate-200 dark:border-slate-800">
            <span className="text-emerald-700 dark:text-emerald-400 font-bold block mb-1">सही प्रश्न (Correct)</span>
            <span className="text-slate-700 dark:text-slate-300">प्रत्येक प्रश्न पर 1.0 अंक जोड़ा जाता है।</span>
          </div>
          <div className="bg-slate-50 dark:bg-slate-950/60 p-3 rounded-lg border border-slate-200 dark:border-slate-800">
            <span className="text-rose-700 dark:text-rose-400 font-bold block mb-1">गलत प्रश्न (Wrong)</span>
            <span className="text-slate-700 dark:text-slate-300">प्रत्येक गलत प्रश्न पर 0.25 अंक घटाया जाता है।</span>
          </div>
          <div className="bg-slate-50 dark:bg-slate-950/60 p-3 rounded-lg border border-slate-200 dark:border-slate-800">
            <span className="text-slate-500 dark:text-slate-400 font-bold block mb-1">अनुत्तरित (Unattempted)</span>
            <span className="text-slate-700 dark:text-slate-300">शून्य (0) अंक — कोई अंक नहीं कटता।</span>
          </div>
        </div>
      </div>

      {/* 2. Why No Normalization in Phase 1 (Blueprint #3) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4 shadow-xs">
        <div className="flex items-center gap-2 text-rose-600 dark:text-rose-400 font-semibold text-sm">
          <AlertTriangle className="w-5 h-5" />
          <span>फेज-1 में Normalization क्यों नहीं है? (No Normalization Rule)</span>
        </div>

        <div className="space-y-3 text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
          <p>
            ब्लूप्रिंट के मुख्य सिद्धांत (Core Principle - Raw Data First) के अनुसार वर्तमान चरण में:
          </p>
          <ul className="list-disc pl-5 space-y-1.5 text-slate-700 dark:text-slate-300">
            <li>कोई काल्पनिक नॉर्मलाइज्ड अंक (Normalized Marks) नहीं निकाले गए हैं।</li>
            <li>किसी शिफ्ट को कृत्रिम रूप से स्केल या एडजस्ट नहीं किया गया है।</li>
            <li>सभी रैंक व आंकड़े केवल <strong>सत्यापित रॉ मार्क्स (Raw Marks)</strong> पर आधारित हैं।</li>
          </ul>
          <p className="bg-slate-50 dark:bg-slate-950 p-3 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400">
            भविष्य में, जब सभी 22 शिफ्ट्स से पर्याप्त नमूना (Statistical Sample Size) प्राप्त हो जाएगा, तब आधिकारिक Normalised Equi-Percentile (NEP) स्केलिंग पद्धति के अनुसार विश्लेषण जोड़ा जा सकेगा।
          </p>
        </div>
      </div>

      {/* 3. Competition Ranking & Tie-Breaker (Blueprint #38) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4 shadow-xs">
        <div className="flex items-center gap-2 text-cyan-600 dark:text-cyan-400 font-semibold text-sm">
          <CheckCircle2 className="w-5 h-5" />
          <span>रैंकिंग प्रणाली व टाई-ब्रेकिंग (Competition Ranking: 1, 2, 2, 4)</span>
        </div>

        <div className="text-xs text-slate-700 dark:text-slate-300 space-y-2 leading-relaxed">
          <p>
            Rank Mitra मानक <strong>प्रतियोगिता रैंकिंग (Standard Competition Ranking)</strong> का उपयोग करता है:
          </p>
          <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 font-mono text-slate-800 dark:text-slate-200">
            यदि दो या अधिक अभ्यर्थियों के रॉ अंक समान (Tie) होते हैं, तो उन्हें समान रैंक प्रदान की जाती है और अगले स्थान को तदनुसार आगे बढ़ाया जाता है (उदा. 1, 2, 2, 4)।
          </div>
          <p>
            बिना आधिकारिक जन्मतिथि व अन्य टाई-ब्रेकर नियमों के किसी भी अभ्यर्थी को कृत्रिम रूप से ऊपर या नीचे नहीं दिखाया जाता।
          </p>
        </div>
      </div>

      {/* 4. Privacy Guarantee (Blueprint #16 & #63) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-4 shadow-xs">
        <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-semibold text-sm">
          <ShieldCheck className="w-5 h-5" />
          <span>गोपनीयता व डेटा सुरक्षा नीति (Privacy-Preserving Architecture)</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1">
            <span className="font-semibold text-slate-900 dark:text-white block">1. कोई फ़ाइल संचयन नहीं</span>
            <p className="text-slate-600 dark:text-slate-400">
              आपकी अपलोड की गई HTML/MHTML उत्तर कुंजी फ़ाइल को सर्वर पर संचित (Persist) नहीं किया जाता। पार्सिंग क्लाइंट-साइड ब्राउज़र में ही संपन्न होती है।
            </p>
          </div>
          <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-1">
            <span className="font-semibold text-slate-900 dark:text-white block">2. नाम का मास्किंग</span>
            <p className="text-slate-600 dark:text-slate-400">
              सार्वजनिक लीडरबोर्ड में उम्मीदवार का पूरा नाम प्रदर्शित नहीं किया जाता (उदा. "RAHUL K****") तथा रोल नंबर पूरी तरह गोपनीय रहता है।
            </p>
          </div>
        </div>
      </div>

      {/* 5. Official Source Citation (Blueprint #93) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 space-y-3 shadow-xs text-xs">
        <div className="flex items-center gap-2 text-slate-800 dark:text-slate-300 font-semibold text-sm">
          <FileCode className="w-4 h-4 text-amber-500 dark:text-amber-400" />
          <span>आधिकारिक स्रोत (Official Sources)</span>
        </div>
        <p className="text-slate-600 dark:text-slate-400 leading-relaxed">
          इस प्लेटफॉर्म पर प्रदर्शित पद, वेतनमान, श्रेणीवार रिक्तियां तथा शैक्षणिक योग्यताएं म.प्र. कर्मचारी चयन मंडल, भोपाल (MPESB) द्वारा जारी <strong>"समूह-02 उपसमूह-04 संयुक्त भर्ती परीक्षा-2026 परीक्षा संचालन एवं भर्ती नियमपुस्तिका"</strong> (145 पृष्ठ) के अनुसार सत्यापित हैं।
        </p>
      </div>
    </div>
  );
};
