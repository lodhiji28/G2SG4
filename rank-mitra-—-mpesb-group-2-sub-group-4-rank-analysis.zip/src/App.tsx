/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { CandidateRecord, ShiftStats } from './types';
import { 
  getCandidates, 
  getCurrentUserRoll, 
  setCurrentUserRoll, 
  getLastRefreshTime, 
  updateRefreshTime 
} from './lib/storage';
import { calculateShiftStats } from './lib/ranking';
import { Navbar, NavTab } from './components/Navbar';
import { DashboardView } from './components/DashboardView';
import { ShiftAnalysisView } from './components/ShiftAnalysisView';
import { ShiftCompareView } from './components/ShiftCompareView';
import { LeaderboardView } from './components/LeaderboardView';
import { VacanciesView } from './components/VacanciesView';
import { MyProfileRankView } from './components/MyProfileRankView';
import { UploadAnswerKeyView } from './components/UploadAnswerKeyView';
import { MethodologyView } from './components/MethodologyView';
import { AdminView } from './components/AdminView';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [candidates, setCandidates] = useState<CandidateRecord[]>([]);
  const [currentUserRoll, setCurrentUserRollState] = useState<string | null>(null);
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());
  
  // Shift compare initial params
  const [compareShiftA, setCompareShiftA] = useState<number>(1);
  const [compareShiftB, setCompareShiftB] = useState<number>(2);

  // Initialize data on mount
  useEffect(() => {
    const loadedCandidates = getCandidates();
    setCandidates(loadedCandidates);

    const activeRoll = getCurrentUserRoll();
    setCurrentUserRollState(activeRoll);

    const refreshTime = getLastRefreshTime();
    setLastRefresh(refreshTime);
  }, []);

  // Compute shift stats across dataset
  const shiftStats: ShiftStats[] = useMemo(() => {
    return calculateShiftStats(candidates);
  }, [candidates]);

  // Refresh handler (30 min cycle or manual click, Blueprint #34 & #68)
  const handleManualRefresh = () => {
    updateRefreshTime();
    const loaded = getCandidates();
    setCandidates(loaded);
    setLastRefresh(new Date());
  };

  // Callback when a user successfully submits their key
  const handleSubmissionSuccess = (submittedRoll: string) => {
    const updated = getCandidates();
    setCandidates(updated);
    setCurrentUserRollState(submittedRoll);
    setCurrentUserRoll(submittedRoll);
    setActiveTab('my-rank');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Callback to compare two shifts from shift analysis table
  const handleTriggerCompare = (shiftA: number, shiftB: number) => {
    setCompareShiftA(shiftA);
    setCompareShiftB(shiftB);
    setActiveTab('compare');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Callback when clicking a candidate in leaderboard
  const handleSelectCandidate = (candidate: CandidateRecord) => {
    setCurrentUserRollState(candidate.rollNumber);
    setCurrentUserRoll(candidate.rollNumber);
    setActiveTab('my-rank');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 dark:bg-slate-950 dark:text-slate-100 flex flex-col font-sans selection:bg-amber-500/30 selection:text-amber-800 dark:selection:text-amber-200 transition-colors">
      {/* 3-Zone Top Bar & Mobile Navigation */}
      <Navbar
        activeTab={activeTab}
        onTabChange={(tab) => {
          setActiveTab(tab);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        lastRefresh={lastRefresh}
        onRefreshClick={handleManualRefresh}
        hasUserSubmitted={Boolean(currentUserRoll)}
      />

      {/* Main Viewport Container (1440px baseline with responsive padding) */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-20 lg:pb-12">
        {activeTab === 'dashboard' && (
          <DashboardView
            candidates={candidates}
            shiftStats={shiftStats}
            lastRefresh={lastRefresh}
            onNavigate={(tab) => {
              setActiveTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {activeTab === 'shifts' && (
          <ShiftAnalysisView
            candidates={candidates}
            shiftStats={shiftStats}
            onCompareShifts={handleTriggerCompare}
          />
        )}

        {activeTab === 'compare' && (
          <ShiftCompareView
            candidates={candidates}
            shiftStats={shiftStats}
            initialShiftA={compareShiftA}
            initialShiftB={compareShiftB}
          />
        )}

        {activeTab === 'leaderboard' && (
          <LeaderboardView
            candidates={candidates}
            currentUserRoll={currentUserRoll}
            onSelectCandidate={handleSelectCandidate}
          />
        )}

        {activeTab === 'vacancies' && (
          <VacanciesView candidates={candidates} />
        )}

        {activeTab === 'my-rank' && (
          <MyProfileRankView
            candidates={candidates}
            currentUserRoll={currentUserRoll}
            onSelectRoll={(roll) => {
              setCurrentUserRollState(roll);
              setCurrentUserRoll(roll);
            }}
            onNavigateToUpload={() => {
              setActiveTab('upload');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}

        {activeTab === 'upload' && (
          <UploadAnswerKeyView
            onSubmissionSuccess={handleSubmissionSuccess}
          />
        )}

        {activeTab === 'methodology' && (
          <MethodologyView />
        )}

        {activeTab === 'admin' && (
          <AdminView
            candidates={candidates}
            shiftStats={shiftStats}
            onRefreshData={handleManualRefresh}
          />
        )}
      </main>

      {/* Clean Trustworthy Footer */}
      <footer className="bg-white dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 text-xs py-8 px-4 sm:px-6 lg:px-8 mt-auto transition-colors">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2">
              <span className="font-bold text-slate-900 dark:text-white text-sm">Rank Mitra / Rank Guru</span>
              <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300">
                MPESB Group-2 Sub-Group-4
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 max-w-xl">
              यह एक निष्पक्ष व स्वतंत्र छात्र विश्लेषण मंच है। प्रदर्शित आंकड़े केवल सबमिट की गई उत्तर कुंजियों के रॉ मार्क्स पर आधारित हैं।
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-medium text-slate-600 dark:text-slate-400">
            <button
              onClick={() => { setActiveTab('methodology'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="hover:text-amber-600 dark:hover:text-amber-400 transition-colors cursor-pointer"
            >
              गणना नियम
            </button>
            <span className="text-slate-300 dark:text-slate-700">·</span>
            <button
              onClick={() => { setActiveTab('vacancies'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="hover:text-amber-600 dark:hover:text-amber-400 transition-colors cursor-pointer"
            >
              पद व रिक्तियां
            </button>
            <span className="text-slate-300 dark:text-slate-700">·</span>
            <button
              onClick={() => { setActiveTab('admin'); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
              className="hover:text-amber-600 dark:hover:text-amber-400 transition-colors cursor-pointer"
            >
              प्रशासक पोर्टल
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
