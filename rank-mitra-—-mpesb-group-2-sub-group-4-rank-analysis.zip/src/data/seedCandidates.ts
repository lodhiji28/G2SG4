import { CandidateRecord, Category, Gender } from '../types';
import { calculateRawScore, maskCandidateName } from '../lib/scoring';
import { EXAM_SHIFTS } from './shifts';
import { MASTER_QUALIFICATIONS } from './vacancies';

// Helper to seed realistic candidate entries across all 22 shifts
const FIRST_NAMES = [
  'ABHISHEK', 'AJAY', 'AKASH', 'ALOK', 'AMAN', 'ANIKET', 'ANIL', 'ANKIT', 'ANSHUL', 'ANURAG',
  'ARUN', 'ASHISH', 'ATUL', 'AYUSH', 'BHUPENDRA', 'CHANDAN', 'CHETAN', 'DARSHAN', 'DEEPAK', 'DEVENDRA',
  'DHARMEṆDRA', 'DINESH', 'GAURAV', 'GOPAL', 'HEMANT', 'HITESH', 'JAGDISH', 'JITENDRA', 'KAMAL', 'KAPIL',
  'KESHAV', 'KISHORE', 'KULDEEP', 'LOKESH', 'MANISH', 'MAYANK', 'MOHIT', 'MUKESH', 'NAVEEN', 'NEERAJ',
  'NITESH', 'PANKAJ', 'PAWAN', 'PIYUSH', 'PRADEEP', 'PRAKASH', 'PRATEEK', 'PRAVEEN', 'PRIYANSH', 'RAHUL',
  'RAJESH', 'RAKESH', 'RAMESH', 'RAVI', 'RISHABH', 'ROHIT', 'SACHIN', 'SANDEEP', 'SANJAY', 'SATISH',
  'SAURABH', 'SHIVAM', 'SHUBHAM', 'SOURABH', 'SUNIL', 'SURESH', 'TARUN', 'UMESH', 'VARUN', 'VIKAS',
  'VIKRAM', 'VINAY', 'VIPIN', 'VISHAL', 'VIVEK', 'YOGESH',
  // Female names
  'AANCHAL', 'AARTI', 'ADITI', 'ANJALI', 'ANKITA', 'ARCHANA', 'BHAWNA', 'CHHAYA', 'DEEPIKA', 'DIVYA',
  'GEETA', 'HEMA', 'ISHITA', 'JYOTI', 'KAJAL', 'KAMINI', 'KAVITA', 'KHUSHBOO', 'KIRAN', 'KOMAL',
  'KRITI', 'LAXMI', 'MADHU', 'MANISHA', 'MEGHA', 'MONIKA', 'NANDINI', 'NEELAM', 'NEHA', 'NIDHI',
  'NISHA', 'PAYAL', 'POOJA', 'POONAM', 'PRAGYA', 'PRATIKSHA', 'PREETI', 'PRIYA', 'PRIYANKA', 'RACHNA',
  'RADHA', 'RASHMI', 'REENA', 'RICHA', 'RITU', 'ROSHNI', 'RUBY', 'SAKSHI', 'SANJANA', 'SAPNA',
  'SARITA', 'SEEMA', 'SHALINI', 'SHEETAL', 'SHIKHA', 'SHIVANI', 'SHRADDHA', 'SHREYA', 'SIMRAN', 'SNEHA',
  'SONAM', 'SONALI', 'SURABHI', 'SWATI', 'TANYA', 'TRIPTI', 'URVASHI', 'VAISHALI', 'VANDANA', 'VARSHA'
];

const LAST_NAMES = [
  'SHARMA', 'VERMA', 'TIWARI', 'SINGH', 'PATEL', 'YADAV', 'GUPTA', 'CHOUHAN', 'RATHORE', 'MISHRA',
  'LODHI', 'PANDEY', 'SHUKLA', 'DUBEY', 'JOSHI', 'SAXENA', 'CHOUDHARY', 'KUSHWAHA', 'MEENA', 'BHARGAWA',
  'SONI', 'JAISWAL', 'THAKUR', 'MALVIYA', 'NIGAM', 'TRIVEDI', 'PATIDAR', 'SAHU', 'SEN', 'PARMAR',
  'DWIVEDI', 'BAJPAI', 'RAWAT', 'TOMAR', 'SOLANKI', 'DHAKAD', 'GURJAR', 'KORI', 'AHIRWAR', 'JATAV'
];

const CATEGORIES: Category[] = ['UR', 'OBC', 'SC', 'ST', 'EWS'];
const CATEGORY_WEIGHTS = [0.30, 0.40, 0.14, 0.08, 0.08];

function pickCategory(): Category {
  const r = Math.random();
  let acc = 0;
  for (let i = 0; i < CATEGORIES.length; i++) {
    acc += CATEGORY_WEIGHTS[i];
    if (r <= acc) return CATEGORIES[i];
  }
  return 'OBC';
}

export function generateSeedCandidates(): CandidateRecord[] {
  const candidates: CandidateRecord[] = [];
  let rollCounter = 22049001;

  // Let's seed ~180 realistic candidates across all 22 shifts
  // Shift performance varies slightly to simulate shift difficulty variance
  const shiftScoreMultipliers = [
    0.96, 1.02, 1.05, 0.94, 0.99, 1.01, 1.06, 0.92, 0.98, 1.03,
    0.95, 1.04, 0.97, 1.01, 0.93, 1.05, 0.98, 1.02, 0.96, 1.00, 1.03, 0.97
  ];

  EXAM_SHIFTS.forEach((shift, sIdx) => {
    // 7 to 10 candidates per shift
    const countInShift = 7 + (sIdx % 4);
    const multiplier = shiftScoreMultipliers[sIdx] || 1.0;

    for (let c = 0; c < countInShift; c++) {
      const isFemale = c % 3 === 0;
      const firstName = isFemale
        ? FIRST_NAMES[76 + ((sIdx * 3 + c) % (FIRST_NAMES.length - 76))]
        : FIRST_NAMES[(sIdx * 4 + c) % 76];
      const lastName = LAST_NAMES[(sIdx * 5 + c * 2) % LAST_NAMES.length];
      const fullName = `${firstName} ${lastName}`;

      const rollNumber = String(rollCounter++);
      const category = pickCategory();
      const gender: Gender = isFemale ? 'Female' : 'Male';

      // Base correct answers between 95 and 172
      const baseScore = 95 + ((sIdx * 17 + c * 29) % 75);
      const adjustedCorrect = Math.min(182, Math.max(78, Math.round(baseScore * multiplier)));
      const wrong = Math.min(65, Math.max(12, Math.round(30 + ((c * 7) % 25))));
      const score = calculateRawScore(adjustedCorrect, wrong, 200);

      // Assign qualifications
      const qualCount = 2 + (c % 3);
      const candidateQuals: string[] = [MASTER_QUALIFICATIONS[0]]; // Graduation
      if (c % 2 === 0) candidateQuals.push(MASTER_QUALIFICATIONS[1]); // CPCT
      if (c % 3 === 0) candidateQuals.push(MASTER_QUALIFICATIONS[2]); // Computer Diploma
      if (category === 'OBC' && c % 4 === 0) candidateQuals.push(MASTER_QUALIFICATIONS[3]); // B.Com
      if (c % 5 === 0) candidateQuals.push(MASTER_QUALIFICATIONS[4]); // B.Sc.

      candidates.push({
        id: `cand-${rollNumber}`,
        examId: 'mpesb-g2sg4-2026',
        rollNumber,
        candidateNamePrivate: fullName,
        candidateNamePublic: maskCandidateName(fullName),
        examDate: shift.displayDate,
        shiftId: shift.id,
        shiftNumber: shift.shiftNumber,
        totalQuestions: 200,
        attempted: score.attempted,
        unattempted: score.unattempted,
        correct: score.correct,
        wrong: score.wrong,
        rawScore: score.rawScore,
        accuracy: score.accuracy,
        category,
        gender,
        exServiceman: c === 1 && sIdx % 5 === 0,
        contractStatus: c === 2 && sIdx % 3 === 0,
        qualifications: Array.from(new Set(candidateQuals)),
        submittedAt: new Date(Date.now() - (sIdx * 3600000 + c * 600000)).toISOString(),
      });
    }
  });

  return candidates;
}
